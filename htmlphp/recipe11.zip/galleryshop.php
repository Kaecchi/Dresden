<html>

<head>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"> </script>
     <script src="js/galeryshop.js"></script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>photo show</title>
  	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS --> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<link href="css/galleryshop.css" rel="stylesheet">
  <link href="css/menufooter.css" rel="stylesheet">
  <link rel="stylesheet" href="fontello-aa345661/css/fontello.css">

  
</head>
 
<body>

 <a class="logoo" href="index.html"><img src="img/logoofficial.png"></a>
		 <nav>
	 
		<ul class="me">
            
            <li class="firstt"><a href="index.html">Home</a></li>
			<li><a class="tu">Shop</a></li>
			<li  class="sr"><a href="contactus.html">Contact us</a></li>
			<li><a href="aboutus.html">About us</a></li>
			
		</ul>
    </nav>


  <div class="wrapper">
   

<?php
    include 'added.html';


 ?>
 
  </div>
  
  	 <footer>


		<div class="socdiv" >
			<a style="padding-bottom: 10px; padding-top: 15px;" class="icon-youtube-squared  , soc" href="https://www.youtube.com/"></a>
			<a style="padding-bottom: 10px; padding-top: 15px;" class="icon-twitter-squared  , soc" href="https://www.twitter.com/"></a>
			<a style="padding-bottom: 10px; padding-top: 15px;" class="icon-facebook-squared , soc" href="https://www.facebook.com/"></a>
			<a style="padding-bottom: 10px; padding-top: 15px;" class="icon-linkedin-squared , soc" href="https://www.linkedin.com/"></a>
		</div>
		<div class="fot1" href="contactus.html">Contact us!</div>
		<div class="fot1" href="aboutus.html">About us!</div>
		<div class="fot2">
			<a>email:ihaha@unicorn.help</a><br>
			<a>phone:666999696</a><br>
			<a>adress:Louisenstraße 20, 01099 Dresden</a><br>
		</div>
	</footer>
	<p class="copyright">&copy; Kamila Wilczynska, Kamil Kowalczyk</p>


</body>